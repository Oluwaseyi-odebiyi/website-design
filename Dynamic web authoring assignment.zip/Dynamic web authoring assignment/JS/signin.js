
function accountIn()
{	
	
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var reg1 = document.getElementById("email");
	var reg2 = document.getElementById("Password");
	var letter = /[a-z]/;
	var upper  =/[A-Z]/;
	var number = /[0-9]/;
	var result =reg1.value;
	var result2 =reg2.value;
	var valid = true;
	var msg;

	if ((result2.length >= 6) && letter.test(result2) && upper.test(result2) && number.test(result2) && filter.test(result) )
	{

		window.open("welcome.html");
		
	} 
	
		 if (result2.length < 6) 
		{
		 		
		 msg="Please ensure your password is longer than 6 characters.";
		 valid = false;
				 
		}

		 if (!letter.test(result2) || !upper.test(result2)) 
		{
            	 msg ="Please ensure at least one uppercase and lowercase character must be included in your password";		 
   	     	 valid = false;
		}
		 if (!number.test(result2)) 
		{
            	 msg="Please make ensure Password includes a number";
		 valid = false;
        	}
		 if (!filter.test(result))
		{
		 msg= "Please enter a valid email address";
		 valid = false;
		} 

		document.getElementById("error").innerHTML = msg;
  		return valid;
			
		
}




