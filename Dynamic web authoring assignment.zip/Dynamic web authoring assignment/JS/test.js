
function finalSignUp ()
{
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var result = document.getElementById("email").value;
	var result2 = document.getElementById("Password").value;
	var fname= document.getElementById("fname").value;
	var lname= document.getElementById("lname").value;
	var cpass= document.getElementById("cpassword").value;
	var checkbo= document.getElementById("privacy");
	var letter = /[a-z]/;
	var upper  =/[A-Z]/;
	var number = /[0-9]/;
	

  	if ((fname.length > 3) && !(number.test(fname)) && (lname.length > 3) && !(number.test(lname)) && (result2.length >= 6) && letter.test(result2) && filter.test(result) && result2==cpass && upper.test(result2) && number.test(result2) && (checkbo.checked))	
	{

		window.open("Login_page.html");
	
	}
	else
	{
	
	 if ((fname.length < 3) || (number.test(fname)))
	{
		document.getElementById("fname1").innerHTML="Firstname is too short,do not include number";
		document.getElementById("fname1").style.color="red";
		document.getElementById("fname").focus();
		document.getElementById("fname").style.border="2px solid red";
		            
	}

	
	if ( (number.test(lname)) || (lname.length < 3))
	{
		document.getElementById("fname1").innerHTML="Lastname is too short,do not include number";
		document.getElementById("fname1").style.color="red";
		document.getElementById("lname").focus();
		document.getElementById("lname").style.border="2px solid red";
		           
	}
	
	 if (!filter.test(result))
	{
		document.getElementById("fname1").innerHTML="Please check your E-mail address.";
		document.getElementById("fname1").style.color="red";
		document.getElementById("email").style.border="2px solid red";
		document.getElementById("email").focus();
		
	}

	
	 if (result2.length < 6)
	{	
		document.getElementById("password0").innerHTML="Password is too short,ensure your password is longer than 6 characters";
		document.getElementById("password0").style.color="red";
		document.getElementById("Password").focus();
		document.getElementById("Password").style.border="2px solid red";
			 
	}
	

	  if (!letter.test(result2) && !upper.test(result2))
	{ 	
		document.getElementById("password1").innerHTML="Please ensure at least one uppercase and lowercase character must be included in your password.";
		document.getElementById("password1").style.color="red";
		document.getElementById("Password").focus();
		document.getElementById("Password").style.border="2px solid red";
		
        }
	  if (!number.test(result2))
	{ 	
		document.getElementById("number").innerHTML="Please ensure at least one uppercase and lowercase character must be included in your password.";
		document.getElementById("number").style.color="red";
		document.getElementById("Password").style.border="2px solid red";
		document.getElementById("Password").focus();
		
        }

	if (result2 !== cpass)
	{	
		document.getElementById("cpassword1").innerHTML="The password do not match";
		document.getElementById("cpassword1").style.color="red";
		document.getElementById("cpassword").focus();
		document.getElementById("cpassword"). style.border="2px solid red";
		     
        }

	
	  if (!(checkbo.checked))
	{	
		document.getElementById("pri").innerHTML="Read and tick our Terms of service, privacy policy and notification setting.";
		document.getElementById("pri").style.color="red";
		
				 
	}
	  
	 
	}		
	
}


/*valid and invalid email address with image */

function checkMail(reg1)
{
	var $sysmbols = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var reg1 = document.getElementById("email").value;	

		if($sysmbols.test(reg1) == false)
		{
	   	document.getElementById("status").src="media/bad.jpg";    
	   	document.getElementById("status").style.visibility="visible";  // set the image visible
	   
		} 
	 	else if($sysmbols.test(reg1) == true)
		{
	 	 document.getElementById("status").src="media/mark.png";
	 	 document.getElementById("status").style.visibility="visible";
	
		}

}

/*click for login page*/

function login()
{
window.open("Login_page.html");
}
