
/*drop down in home page*/
function cinema() 
        {
	document.getElementById("myDropdown").classList.toggle("show");
	}

	window.onclick = function(event) 
{
	if (!event.target.matches('.cinema')) 
	{
	var dropdowns = document.getElementsByClassName("dropdown-content");
	var i;
	for (i = 0; i < dropdowns.length; i++) 
	{
	var openDropdown = dropdowns[i];
	if (openDropdown.classList.contains('show'))
	 {
	openDropdown.classList.remove('show');
	 }
	}
	}
}


  /*to login*/

function accountIn()

{

	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var reg1 = document.getElementById("email");
	var reg2 = document.getElementById("Password");
	var letter = /[a-z]/;
	var upper  =/[A-Z]/;
	var number = /[0-9]/;
	var result =reg1.value;
	var result2 =reg2.value;;
		

	if ((result2.length >= 6) && letter.test(result2) && upper.test(result2) && number.test(result2) && filter.test(result) )
	{
		window.open("welcome.html");	
		return true;
			
	} 
	else
	{

		 if (result2.length < 6 && !letter.test(result2) && !number.test(result2) && !upper.test(result2) && !filter.test(result))
		{	

		document.getElementById("error").innerHTML="Please enter your Email and password ";
		document.getElementById("error").style.color="red";
		document.getElementById("Password").style.border="2px solid red";
		document.getElementById("email").style.border="2px solid red";
		return false;

		}
		
		if (!filter.test(result))
		{
		document.getElementById("error1").innerHTML="Invalid E-mail address, please enter your E-mail address";
		document.getElementById("error1").style.color="red";
		document.getElementById("email").style.border="2px solid red";
		document.getElementById("email").focus();
		return false;

		}
	
		 if (result2.length < 6)
		{

		document.getElementById("error1").innerHTML="Please ensure your password is longer than 6 characters.";
		document.getElementById("error1").style.color="red";
		document.getElementById("Password").style.border="2px solid red";
		document.getElementById("Password").focus();
		return false;
		
		}
		if (!letter.test(result2) || !upper.test(result2))
		{

		document.getElementById("error1").innerHTML="Please ensure at least one uppercase and lowercase character must be included in your password.";
		document.getElementById("error1").style.color="red";
		document.getElementById("Password").style.border="2px solid red";
		document.getElementById("Password").focus();
		return false;
		}

		if (!number.test(result2))
		{
		document.getElementById("error").innerHTML="Please ensure password includes a number.";
		document.getElementById("error").style.color="red";
		document.getElementById("Password").style.border="2px solid red";
		document.getElementById("Password").focus();
		return false;	
		}	

	}

					
		
}

/*Movie details display*/

function portals() 
{
  document.getElementById("portals_m").style.visibility ="visible";
  document.getElementById("movieDetailsImage").src="Images/http___imghost.device.screenmedia.net_5db62e0f-b1c2-4c10-9335-8d362b9359a0-1593025778.png";
}

 function closePortal() 
{
 
  document.getElementById("portals_m").style.visibility ="hidden";
}



/*sign up button*/

function $signin()
{
	window.open("Sign_up.html");
}


/*for forgot password*/

function forgot_Pass() 
{
  window.open("forgot_password.html");
}

/*valid and invalid email address with image */

function checkMail(reg1)
{
	var $sysmbols = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
	var reg1 = document.getElementById("email").value;
	
	if($sysmbols.test(reg1) == false)
	{
	   document.getElementById("status").src="media/bad.jpg";    
	   document.getElementById("status").style.visibility="visible";  // set the image visible
	   
	} 
	 else if($sysmbols.test(reg1) == true)
	{
	  document.getElementById("status").src="media/mark.png";
	  document.getElementById("status").style.visibility="visible";
	}

}

/*click for login page*/

function login()
{
window.open("Login_page.html");
}


/*To validate the Email in forgot password page*/

function validateEmail()
	{
	var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
        var reg = document.getElementById("email");
	
        if ( (reg && reg.value) && filter.test(reg.value)) 
        {
            	alert('Reset link has been sent to your E-mail'); 
            
        }
	else{
           	document.getElementById("error").innerHTML="Please enter a valid email address";
		document.getElementById("error").style.color="red";
		document.getElementById("email").style.border="2px solid red";
		document.getElementById("email").focus();
	    }
	}

 function showimage()
{
	
	if (document.getElementById("Action").checked)
	{
		document.getElementById("images1").src="media/actionM.jpg";
		document.getElementById("images1").style.visibility="visible";
		
	}

	 if (document.getElementById("Animation").checked)
	{
		document.getElementById("images1").src="media/frozen.jpg";
		document.getElementById("images1").style.visibility="visible";
		
	}

	if (document.getElementById("Thriller").checked)
	{
		document.getElementById("images1").src="media/johnw.jpg";
		document.getElementById("images1").style.visibility="visible";		
	}
	
	if (document.getElementById("Romance").checked)
	{
		document.getElementById("images1").src="media/fifty-shades-grey.jpg";
		document.getElementById("images1").style.visibility="visible";		
	}

	if (document.getElementById("Adventures").checked)
	{
		document.getElementById("images1").src="media/hunger-games-catching-fire-movie-poster.jpg";
		document.getElementById("images1").style.visibility="visible";		
	}
	
	if (document.getElementById("Sci-fi").checked)
	{
		document.getElementById("images1").src="media/avatar_2.jpg";
		document.getElementById("images1").style.visibility="visible";		
	}

	 if (document.getElementById("Horror").checked)
	{
		document.getElementById("images1").src="media/Us.jpg";
		document.getElementById("images1").style.visibility="visible";		
	}

}


/*Time and date */

function renderTime()
{
	// for date
	var myDate = new Date();
	var year = myDate.getYear(); // create an object of date for getting year
		if (year < 1000)
		{
			year+= 1900; // to ammend the technical defect of years in javascript
		}

	var day = myDate.getDay();  // to get day of the month 
	var month =myDate.getMonth();  // to get month of the year
	var dayM = myDate.getDate();
	var weekDay = new Array("Sunday,", "Monday,", "Tuesday,", "Wednesday,", "Thusday,", "Friday,", "Saturday,");  // for days of the week
	var monthYear = new Array ("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");  // for month of the year
	
	// Time
	var currentTime = new Date();
	var hr = currentTime.getHours();
	var min =currentTime.getMinutes();
	var sec = currentTime.getSeconds();
	var format ="";
				
			// AM and PM time format
		if ( hr >= 12)
		{
			hr = hr-12;
			format="Pm"
		}
		else if (hr < 12)
		{
			format="Am";
		}

			// to digitalize the time output "09" when hour is less than 10	

		if (hr < 10)
		{
			hr = "0"+ hr;
		}

		if (min < 10)
		{
			min = "0"+ min;
		}

		if (sec < 10)
		{
			sec = "0"+ sec;
		}

	
	document.getElementById("displayClock").innerHTML= weekDay[day]+ " " +dayM+ " " +monthYear[month]+ " " +year+ " | " +hr+ " : " +min+ " : " +sec+" "+format;
	setTimeout("renderTime()",1000); // triggers the counting of the seconds 1000ms =1s

}

function validAll()
{

	var userName= document.userSurvey.userName.value;
			

  	if (userName == "" || userName.length < 3 ) 
	{
    	
	alert("Kindly fill in your name (It must be greater than 2 letters)");
	document.userSurvey.userName.focus();
    	return false;
  	}

	if (!document.userSurvey.phone.value )
	{

	window.alert("Phone number missing. Please enter a valid phone number to continue{}.");
	document.userSurvey.phone.focus();
	return false;

	}
	else
	{

		if (document.userSurvey.phone.value.length != 11)
		{

		window.alert("Incorrect phone number format.You must enter 11 numbers.");
		document.userSurvey.phone.focus();
		return false;

		}	
	}
	

	if (!document.userSurvey.eMail.value) 
	{
	window.alert("E-mail Address missing. Please enter a valid E-mail address to continue.");
	document.userSurvey.eMail.focus();
	return false;
	}

	else
	{

	var emailAddress = document.userSurvey.eMail.value;
	var atLoc = emailAddress.indexOf("@",1);
	var dotLoc = emailAddress.indexOf(".",atLoc+2);
	var len = emailAddress.length;
	
		if (atLoc > 0 && dotLoc > 0 && len > dotLoc+2)
		{
		
		}
		else
		{
		alert("Invalid E-mail address! Please enter your email address again.");
		document.userSurvey.eMail.focus();
		return false;
		}
	
	}

	alert("Our Compliance team is working on your enquires, we will get back to you soon \n\nThank you.");

}

function home()
{	
	window.open("Home_page.html");
}

/*For the advert in Booking page*/

	var myAdvert = new Array();
	myAdvert[0] = new Image();
	myAdvert[1] = new Image();
	myAdvert[2] = new Image();
	myAdvert[3] = new Image();
	myAdvert[4] = new Image();
	myAdvert[5] = new Image();
	myAdvert[6] = new Image();
	myAdvert[7] = new Image();
	myAdvert[8] = new Image();

	myAdvert[0].src= "media/placeadvert.jpg";
	myAdvert[1].src="media/naijapot.jpg";
	myAdvert[2].src="media/mcdonald.jpg";
	myAdvert[3].src="media/peak.jpg";
	myAdvert[4].src="media/argo.jpg";
	myAdvert[5].src="media/rolex.jpg";
	myAdvert[6].src="media/enex.jpeg";
	myAdvert[7].src="media/maggi.jpg";
	myAdvert[8].src="media/oasis.jpg";
	
	var banner=0;

function showAd()
	{ 
		if (document.images)
		{
		 banner++;
		if (banner == myAdvert.length) 
		{
			banner=0;
		}
		document.getElementById("advert").src = myAdvert[banner].src;
		setTimeout("showAd()",5000); // advertised picture changes at evry 5second

		}
	}

/*to display price of the movie */
function showPromo()
{
	var promo= document.getElementById("numberOfTicket").value;
	var vip= document.getElementById("VIP").checked
	var standard= document.getElementById("standard").checked;
	var premium= document.getElementById("Premium").checked;
	var rnd;
	var total;

		if (promo !="" && vip)
		{
			total=(promo*10.99);
			rnd = total.toFixed(2);
			document.getElementById("amount").value ="£ "+rnd;
			document.getElementById("amount").style.width="120px";	

		if(promo >= 2 && vip)
		{
			document.getElementById("promo").src="media/popcorn.jpg";
			document.getElementById("promo").style.visibility="visible";
			document.getElementById("promo-text").innerHTML="You have "+promo+" free popcorn";
			
		} 
		}
		
		if(promo >= 1 && premium)
		{
			total=(promo*99.99);
			rnd = total.toFixed(2);
			document.getElementById("amount").value ="£ "+total+" per month";
			document.getElementById("amount").style.width="250px";
			document.getElementById("promo").src="media/popcorn.jpg";
			document.getElementById("promo").style.visibility="visible";
			document.getElementById("promo-text").innerHTML="You have "+promo+" free popcorn,a reserved seat and 3D glass";
		} 
		
		if (promo !="" && standard)
		{
			total=(promo*7.99);
			rnd = total.toFixed(2);
			document.getElementById("amount").value ="£ "+total;
			document.getElementById("amount").style.width="100px";

		if(promo >= 4 && standard)
		{
			document.getElementById("promo").src="media/popcorn.jpg";
			document.getElementById("promo").style.visibility="visible";
			document.getElementById("promo-text").innerHTML="You have "+promo+" free popcorn";
		} 
		}



}

function showTicketPrice()
{
	if (document.getElementById("standard").checked)
		{
			document.getElementById("images").src="media/standard.jpg";
			document.getElementById("showTicketChoice").innerHTML="Standard price : £ 7.99";
			document.getElementById("images").style.visibility="visible";	
		}

	if (document.getElementById("VIP").checked)
		{
			document.getElementById("images").src="media/vip.jpg";
			document.getElementById("showTicketChoice").innerHTML="VIP price : £ 10.99";
			document.getElementById("images").style.visibility="visible";	
		}

	 if (document.getElementById("Premium").checked)
		{
			document.getElementById("images").src="media/premium.jpg";
			document.getElementById("showTicketChoice").innerHTML="Premium price : £ 99.99/month";
			document.getElementById("images").style.visibility="visible";	
		}

}


/*card vendor display logo*/

function showPayCard()
{
	
	if (document.getElementById("visa").checked)
	{
		document.getElementById("payImage").src="media/visa.jpg";
		document.getElementById("payImage").style.visibility="visible";		
	}

	 if (document.getElementById("Mastercard").checked)
	{
		document.getElementById("payImage").src="media/mastercard.jpg";
		document.getElementById("payImage").style.visibility="visible";		
	}

	if (document.getElementById("verve").checked)
	{
		document.getElementById("payImage").src="media/verve.jpg";
		document.getElementById("payImage").style.visibility="visible";		
	}
	
	if (document.getElementById("Maestro").checked)
	{
		document.getElementById("payImage").src="media/mestro.jpg";
		document.getElementById("payImage").style.visibility="visible";		
	}

}


   /*Payment validation function*/

function payment()
{		
		var symbolCheck=document.getElementById("code").value.indexOf("~`!#$%^&*+=-[]\\\';,/{}|\":<>?",0); 
		var letter = /[a-z]/;
		var upper  =/[A-Z]/;
		var number = /[0-9]/;
		var cinemaChoice = document.getElementById("cinemaChoice");
 		var selectedValue = cinemaChoice.options[cinemaChoice.selectedIndex].value;
		var cardName = document.getElementById("card-name").value;
		var expiry = document.getElementById("cardExpiration").value;		
		var spaceLoc = cardName.indexOf(" ",1); // check for space location within card name
		var len = cardName.length;
		var myDat = new Date();
		var month = myDat.getMonth() + 1; // javaScript month start from zero 0-11
		var slashLoc = expiry.indexOf("/",1);  // check for forward slash in expiration date format
		var inMonth = expiry.slice(0,2);     // to get the first two input which is consider as month
		var inYear = expiry.slice(3,6);   // last 2 input for year

		
		 if(!(document.getElementById("Action").checked || document.getElementById("Animation").checked || document.getElementById("Thriller").checked || document.getElementById("Romance").checked||document.getElementById("Adventures").checked||document.getElementById("Sci-fi").checked||document.getElementById("Horror").checked) || selectedValue == "selectCinema"  ||!number.test(document.getElementById("numberOfTicket").value || document.getElementById("standard").checked || document.getElementById("VIP").checked || document.getElementById("Premium").checked || document.getElementById("visa").checked || document.getElementById("Mastercard").checked || document.getElementById("verve").checked || document.getElementById("Maestro").checked) || !number.test(document.getElementById("card-number").value) || document.getElementById("card-number").value.length != 16  || (spaceLoc < 2 || len < spaceLoc+3 || len<3) || upper.test(document.getElementById("code").value) || letter.test(document.getElementById("code").value) ||                         document.getElementById("code").value.length <4 || /[~`!@#$%\^&*()+=\-\[\]\\';,/{}|\\":<>\?]/.test(document.getElementById("code").value) || inMonth>12 || slashLoc != 2 || inMonth < month || inYear < 20 || expiry.length<5 || letter.test(expiry) || upper.test(expiry) )
		{			
		
			if(!(document.getElementById("Action").checked || document.getElementById("Animation").checked || document.getElementById("Thriller").checked || document.getElementById("Romance").checked||document.getElementById("Adventures").checked||document.getElementById("Sci-fi").checked||document.getElementById("Horror").checked) )
			{
			document.getElementById("movie-choice").innerHTML ="Choose movie category";
						
			}
				
	   		 if (selectedValue == "selectCinema")
			{
  			document.getElementById("cinema-choice").innerHTML="Please choose where you would like watch the movie";			  
   			
			}

			if(!(document.getElementById("standard").checked || document.getElementById("VIP").checked || document.getElementById("Premium").checked))
			{
			document.getElementById("ticket-choice").innerHTML ="Choose your ticket catergories";
			 
			}

			if( !number.test(document.getElementById("numberOfTicket").value))
			{
			document.getElementById("numberTicket").innerHTML ="Provide number of ticket you would like to purchase";
			document.getElementById("numberOfTicket").style.border="2px solid red";
			document.getElementById("numberOfTicket").focus();
			
			}
			if(!(document.getElementById("visa").checked || document.getElementById("Mastercard").checked || document.getElementById("verve").checked || document.getElementById("Maestro").checked))
			{
			document.getElementById("payment-card").innerHTML ="Choose your card provider";	
					
			}

			if(!number.test(document.getElementById("card-number").value) || document.getElementById("card-number").value.length != 16)
			{
			document.getElementById("card-errormessage1").innerHTML="Check your card number";
			document.getElementById("card-number").style.border="2px solid red";
			document.getElementById("card-number").focus();
			
			}

			if(spaceLoc < 2 || len < spaceLoc+3 || len<3)
			{
			document.getElementById("card-errormessage2").innerHTML="Check your card name";
			document.getElementById("card-name").style.border="2px solid red";
			document.getElementById("card-name").focus();
			
			}
			if(upper.test(document.getElementById("code").value) || letter.test(document.getElementById("code").value) || document.getElementById("code").value.length <4 || /[~`!@#$%\^&*()+=\-\[\]\\';,/{}|\\":<>\?]/.test(document.getElementById("code").value))
			{
			document.getElementById("card-errormessage3").innerHTML="Please check your pin number";
			document.getElementById("code").style.border="2px solid red";
			document.getElementById("code").focus();
			
			}
			if ( inMonth>12 || slashLoc != 2 || inMonth < month || inYear < 20 || expiry.length<5 || letter.test(expiry) || upper.test(expiry))
			{
			document.getElementById("card-errormessage3").innerHTML="Please check the card expiry date";
			document.getElementById("cardExpiration").style.border="2px solid red";
			document.getElementById("cardExpiration").focus();
			
			}
		}
		else		
		{
			alert("Ticket details have been sent to your mail \nThanks for chosing potential movies");
		}
		

} 

	